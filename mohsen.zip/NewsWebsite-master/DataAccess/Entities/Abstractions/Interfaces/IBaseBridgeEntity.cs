﻿namespace DataAccess.Entities.Abstractions.Interfaces
{
    public interface IBaseBridgeEntity : IBaseEntity
    {
    }
}
