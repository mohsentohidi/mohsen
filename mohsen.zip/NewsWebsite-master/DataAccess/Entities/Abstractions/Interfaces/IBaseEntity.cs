﻿namespace DataAccess.Entities.Abstractions.Interfaces
{
    public interface IBaseEntity
    {
        public bool IsDeleted { get; set; }
    }
}
