﻿namespace NewsWebsite.ViewModels
{
    public class DeleteModalViewModel
    {
        public string Id { get; set; }
        public string Title { get; set; }
    }
}
