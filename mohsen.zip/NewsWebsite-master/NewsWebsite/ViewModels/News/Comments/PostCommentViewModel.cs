﻿namespace NewsWebsite.ViewModels.News.Comments
{
    public class PostCommentViewModel
    {
        public string ParentId { get; set; }
        public string Content { get; set; }
        public string Username { get; set; }
    }
}
