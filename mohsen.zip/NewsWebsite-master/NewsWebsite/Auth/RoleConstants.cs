﻿namespace NewsWebsite.Auth
{
    public static class RoleConstants
    {
        public const string Administrator = "Administrator";
        public const string Reporter = "Reporter";
        public const string NormalUser = "NormalUser";
        public const string Delimiter = ",";
    }
}
