﻿using DataAccess.Entities;

namespace Repositories.Interfaces
{
    public interface IUsersRepository : IBaseRepository<User>
    {
    }
}
