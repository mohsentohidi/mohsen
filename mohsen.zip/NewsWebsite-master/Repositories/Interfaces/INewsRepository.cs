﻿using DataAccess.Entities;

namespace Repositories.Interfaces
{
    public interface INewsRepository : IBaseRepository<News>
    {
    }
}
