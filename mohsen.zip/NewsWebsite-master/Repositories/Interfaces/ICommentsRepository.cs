﻿using DataAccess.Entities;

namespace Repositories.Interfaces
{
    public interface ICommentsRepository : IBaseRepository<Comment>
    {
    }
}
