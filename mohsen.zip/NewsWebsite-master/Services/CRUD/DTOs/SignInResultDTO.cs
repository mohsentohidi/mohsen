﻿namespace Services.CRUD.DTOs
{
    public class SignInResultDTO
    {
        public bool IsSucceed { get; set; }
        public bool IsNotAllowed { get; set; }
    }
}
